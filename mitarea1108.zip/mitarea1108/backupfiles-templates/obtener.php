<HTML>
    <HEAD><H1 ALIGN='CENTER' color='3371FF'>EXTRAER ARCHIVOS</H1></HEAD>
<BODY>
<div id='Consulta'>
<TABLE BORDER='1' align= 'center'>
    <thead>
    <tr>
    <th>ID</th>
    <th>DATASHEET_NAME</th>
    <th>LINK</th>
    </tr>
    </thead>
<tbody>
<?php
include ('config/conexion.php');
//require ('leedeserver.php');

    $output =$ID['ID'];
    //echo $output;

$db= new conexion();
    $sql = "SELECT DATASHEET_NAME FROM datasheet WHERE ID = '".$output."'";

     //echo $sql;
    $res_consulta= mysqli_query($db, $sql);
    while($rows=mysqli_fetch_assoc($res_consulta))
    {
    echo "<tr>";
    echo "<td>"; echo $rows['ID']; echo "</td>";
    echo "<td>"; echo $rows['DATASHEET_NAME']; echo "</td>";
    echo "<td>"; echo $rows['LINK']; echo "</td>";
    echo "</tr>"; 
            
    }
?>
</tbody>
</TABLE>
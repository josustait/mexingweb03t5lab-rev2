<?php
//obtener archivo, en este caso los archivos viajan 
//en una carpeta temporal y depsues la mandamos a nuestro server
//tmp_name es la variable que almacena el archivo temporalmente
$nombre_archivo = $_FILES['archivo'] ['name'];
$tipo_archivo = $_FILES['archivo'] ['type'];
$size_archivo = $_FILES['archivo'] ['size'];


if ($_FILES['archivo'] ['error']>0 )
{
	echo "inserta un archivo válido (pdf o word)";
} else
	{
		/*Se colocan los formatos admitidos y el tamaño de archivo se multiplica por
		1024 bytes para tener los Mb permitidos*/
		$archivo_valido= array("application/pdf", "application/doc", "application/docx");
		$filesize = $size_archivo * (pow(1024, 2));
		
		/*Lo siguiente es preparar un arreglo para validar que cumpla con el formato
		requerido y con el tamaño límite*/
		
		if(in_array($_FILES["archivo"]["type"], $archivo_valido) && $_FILES["archivo"]["size"] <= ($filesize))
		{
			/*Crearemos una carpeta que contenga el nombre del archivo*/

			
			$aqui = 'datasheets'. $nombre_archivo.'/'; 
			
			/*Ahora se procede a asignar el nombre al archivo en el directorio*/
			$archivo = $aqui.$_FILES['archivo']['name'];
			
			/*Ahora confirmar que la ruta para almacenar archivo existe*/
			//Si el directorio no existe, lo creamos
			if (!file_exists($aqui))
				{
					mkdir ($aqui);
				}
			//Validamos ahora que archivo esté almacenado en memoria
			if(!file_exists($archivo))
				{   require_once 'directorio.php';
					//esta es la ruta donde se van a guardar los archivos en el server
					//hay que cambiar e path cuando lo suba al servidor de la red
					$a_servidor = $_SERVER['DOCUMENT_ROOT'].$dirname;

					/*con la función move_uploaded_file se envia el archivo hacia el servidor
					con la variable $a_servidor concatenada con la variable $nombre_archivo
					se indica a donde se va a enviar el archivo y con el nombre seleccionado.*/
					$miarchivo= move_uploaded_file($_FILES['archivo']['tmp_name'], $a_servidor.$nombre_archivo);
					
					if($miarchivo)
						{
							echo "Archivo cargado correctamente";
						} else
							{
								echo "Fallo la carga del archivo, intente de nuevo";
							}															
				}else
					{
						echo "El archivo que intentas subir, ya existe!!";
					}
		}else
			{
				echo "Problema al cargar archivo, intente nuevamente, valide tamaño y tipo de documento";
			}
	}

?>
<?php 
header("location:comparte.php");
?>
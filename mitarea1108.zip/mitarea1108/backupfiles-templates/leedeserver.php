<HTML>
    <HEAD><H1 ALIGN='CENTER' color='3371FF'>ARCHIVO DESCARGADO</H1></HEAD>
<BODY>
<DIV CLASS = 'CONTAINER'>
<?php
	include ('config/conexion.php');
	
	header ("Content-Type: application/octet-stream");
	
	$db= new conexion();
	
	$sql = "SELECT DATASHEET_NAME FROM datasheet WHERE ID = 12";
	
	$resultado_sql = mysqli_query($db, $sql);
    

   while($rows= mysqli_fetch_array($resultado_sql))
    {
		//Se asigna el resultado del query a la variable $ruta_archivo
		
		$ruta_archivo = $rows["DATASHEET_NAME"];
		
		//Se obtiene el archivo para descargar.
		
		header ("Content-Disposition: attachment; filename= $ruta_archivo");
            
    }
?>

</DIV>

</BODY>
</HTML>
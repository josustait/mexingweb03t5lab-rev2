<?php
require_once 'config/conexion.php';

idarchivo($_POST['txtdatasheet'], $_POST['txtlink']);

function idarchivo($datasheet, $link)
{
$db= new conexion();

$sql="INSERT INTO DATASHEET txtdatasheet='".$datasheet."', txtlink='".$link."'";
$usr_query=mysqli_query($db, $sql);
}
/*Creamos la variable $id_archivo que es la que va a capturar el
archivo que se quiere almacenar (registro insertado) luego 
lo almacenamos como objeto. la finalidad de la función es traer
lo que hemos guardado como registro  en el query anterior*/

$id_archivo = $mysqli->insert_id;


if ($_FILES["archivo"] ["error"]>0)
{
		echo "inserta un archivo o asegura que sea pdf o word";
	
} else
	{
		/*Se colocan las extensiones de archivo que se van a permitir
		y posteriormente el tamaño límite del archivo*/
		$siestabien = array("application/pdf", "application/doc", "application/docx");
		$filesize = 500;
		
		/*Ahora validamos si el archivo cumple con las extensiones y tamaño. Como
		El tamaño lo queremos en KB multiplicamos la variable $filesize *1024bytes
		para que nos de un total de 500Kb*/
		
		if(in_array($_FILES["archivo"]["type"], $siestabien) && $_FILES["archivo"]["size"] <= ($filesize * 1024))
		{
			/*Crearemos una carpeta para cada archivo dentro de datasheets utilizando
			la variable con la que lo estamos llamando, en este caso $id_archivo*/
			$aqui= 'datasheets'.$id_archivo.'/';
			/*Ahora se procede a asignar el nombre al archivo*/
			$archivo = $aqui.$_FILES["archivo"]["name"];
			
			/*Validamos si la ruta para almacenar existe*/
			if (!file_exists($aqui))
			{
				mkdir($aqui);
			}
			if (!file_exists($archivo))
			{
				/*Movemos el archivo de temporal (formulario) a el directorio declarado en $archivo*/ 
				$miarchivo = @move_uploaded_file($_FILES["archivo"]["tmp_name"], $archivo);
			
			if($miarchivo) 
			{
				echo "Archivo guardado correctamente!!";
			
			}else
				{
				echo "Falló la carga de archivo, porfavor intenta nuevamente!!";
				}
			

			}else
				{
				echo "El archivo que intentas cargar ya existe!!";
				}
		
		} else
			{
			echo "Problema al cargar el archivo intente nuevamente!!";
			}
	
	
	
	}



?>
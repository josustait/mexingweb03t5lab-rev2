<!doctype html>
<html>
<head></head>
<body>
<!--El enctype nos perimte agregar la función del examinar los directorios para seleccionar el archivo -->
<form class = "cargaarchivo" action ="subir.php" method = "POST" enctype = "multipart/form-data">
<table>
<tr>
<td><label for = "archivo">Archivo: </label></td>
<td><input type = "file" name = "archivo" size = "500"> </td>
</tr>
<tr>
<td colspan = "2" style = "text-align: center"><input type = "submit" value = "Guardar datasheet" ></td>
</tr>
</table>
</form>
</body>
</html>
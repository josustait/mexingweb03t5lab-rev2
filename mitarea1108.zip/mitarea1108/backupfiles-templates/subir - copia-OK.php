<?php
//obtener archivo, en este caso los archivos viajan 
//en una carpeta temporal y depsues la mandamos a nuestro server
//tmp_name es la variable que almacena el archivo temporalmente
$nombre_archivo = $_FILES['archivo'] ['name'];
$tipo_archivo = $_FILES['archivo'] ['type'];
$size_archivo = $_FILES['archivo'] ['size'];


if ($_FILES['archivo'] ['error']>0 )
{
	echo "inserta un archivo válido (pdf o word)";
} else
	{
		/*Se colocan los formatos admitidos (para ver que tipo de formato solo se le pone
		un echo a la variable $tipo_archivo) y el tamaño de archivo se multiplica por
		1024 elevado al cuadrado para tener los Mb permitidos debido a que el size está en bytes*/
		
		$archivo_valido= array("application/pdf", "application/doc", "application/docx");
		$size = $size_archivo * ((1024 * 5));
		
		/*Lo siguiente es preparar un arreglo para validar que cumpla con el formato
		requerido y con el tamaño límite*/
		
		if(in_array($_FILES["archivo"]["type"], $archivo_valido) && $_FILES["archivo"]["size"] <= ($size))
		{
			//Creamos el path del directorio donde se guardará el archivo
			require_once 'directorio.php';
			$a_servidor = $_SERVER['DOCUMENT_ROOT']. $dirname;

			//Se procede a mover el archivo temporal al directorio creado
			
			move_uploaded_file ($_FILES['archivo']['tmp_name'],$a_servidor);
			echo "El archivo se a guardado exitosamente y pesa ($size_archivo) bytes..";			
		
		}else
			{
				echo "Problema al cargar archivo, probablemente no es válido, intente nuevamente, valide tamaño y tipo de documento..";
				echo " El archivo pesa: ($size_archivo) bytes";
			}
			
				/*Procedo ahora a indexar el nombre y la ubicación del archivo a la base de datos*/
				include 'config/conexion.php';
				$db = new conexion;
				/*inclumimos el archivo dir.php que es donde guardamos la ruta
				en la cual guardamos el archivo en el servidor.
				*/
				require 'dir.php';
				mysqli_set_charset($db,"utf8");
	
				/*Como vamos a manejar archivos, tuvimos que editar my.ini 
				de mysql para poder soportar los archivos de tamaño límite a 5MB.
				así que una vez modificado el archivo, se cambian los timeout
				de las conexiones de mysql para que no se aborten durante la
				transferencia*/
				//ini_set('myaqli.connect_timeout', 800);
				//ini_set('default_socket_timeout', 800);
	
		     	/*Asignamos una variable para el directorio raíz
	 			posteriormente lo concatenamos con nuestro directorio guardado
			 	en dir.php
	 			*/
				$a_servidor = $_SERVER['DOCUMENT_ROOT'] . $dirname;
	
				/*Creamos el Archivo objetivo que es el que queremos guardar en
    			el servidor y le damos privilegio de solo lectura
				*/
				$archivo_objetivo = fopen ($a_servidor.$nombre_archivo, "r");
	
				//Leemos el contenido del arhivo y su tamaño
				$contenido_archivo = fread ($archivo_objetivo, filesize($a_servidor.$nombre_archivo));
	
				//Le decimos a php que reconozca los slashes del path
	
				$contenido_archivo = addslashes ($contenido_archivo);

				//Cerramos el archivo para no consumir recursos
				fclose ($archivo_objetivo);
	
				//Se ejecuta el query para insertar el archivo en bytes a la base de datos	
				$sql = "INSERT INTO datasheet VALUES ('0','$nombre_archivo','$contenido_archivo','$a_servidor')";
				$sql_result = mysqli_query($db,$sql) or die;
	
				if ($sql > 0)
					{
						echo "Archivo almacenado";
					} else
						{
							echo "No se pudo almacenar en db, solo en carpeta";
						}

		
	}
			
			
	

?>

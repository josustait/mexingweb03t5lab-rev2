<?php
 header("location:subir.php");
?>
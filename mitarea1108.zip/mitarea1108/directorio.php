<?php

$dirname = '/dashboard/scripts/BaseDeDatos/mitarea1108/mitarea1108/datasheets/'.$nombre_archivo.'/';

?>
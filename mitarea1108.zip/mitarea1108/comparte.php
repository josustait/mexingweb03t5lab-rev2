<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<!--
Design by TEMPLATED
http://templated.co
Released for free under the Creative Commons Attribution License

Name       : WellFormed 
Description: A two-column, fixed-width design with dark color scheme.
Version    : 1.0
Released   : 20130731

-->
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link href="http://fonts.googleapis.com/css?family=Source+Sans+Pro:200,300,400,600,700,900" rel="stylesheet" />
<link href="default.css" rel="stylesheet" type="text/css" media="all" />
<link href="fonts.css" rel="stylesheet" type="text/css" media="all" />
<link rel="stylesheet" href="tabla.css">

<!--[if IE 6]><link href="default_ie6.css" rel="stylesheet" type="text/css" /><![endif]-->

</head>
<body>
<div id="logo" class="container">
	<h1><a href="#">PROGRAMACIÓN EN <span>EL SERVIDOR WEB</span></a></h1>
	<p>TAREA POR <a href= "mailito=josustait@gmail.com" rel="nofollow">DANIEL SUSTAITA->UNIR</a></p>
</div>
<div id="menu" class="container">
	<ul>
		<li><a href="index.html" accesskey="1" title="home">INICIO</a></li>
		<li><a href="login.php" accesskey="2" title="login">INGRESAR</a></li>
		<li><a href="somos.html" accesskey="3" title="somos">QUIENES SOMOS</a></li>
		<li><a href="contacto.html" accesskey="4" title="contacto">CONTACTO</a></li>
		<li class="current_page_item"><a href="comparte.html" accesskey="5" title="comparte">COMPARTE DATASHEET</a></li>
		<li><a href="logout.php" accesskey="5" title="logout">SALIR</a></li>
	</ul>
</div>
<div id="banner" class="container"> <img src="images/pics05.jpg" width="1200" height="500" alt="" /></div>

<div id="footer" class="container">
	<div id="fbox1">
	
		<h2 class="title">COMPARTE Links de datasheets</h2>
		<p>En esta página los usuarios pueden subir o borrar datasheets (Solo los que ellos mismos crean)</p> 
		
	<!--Se agrega enctype para manejar archivos -->
		<form class = "form-horizontal" method = "POST" action = "upload.php" enctype = "multipart/form-data" enautocomplete = "off">
		
		<div class = "form-group">
		<label for = "archivo" class = "etiqueta">Carga Archivo</label>
		<div class = "miforma">
		<!-- Ahora clasificamos solo los archivos que queramos que se vean con accept, sin embargo si el usuario le da all files, los va a ver, para
		esto lo restringiremos desde el archivo upload.php-->
		<input type = "file" class = "form-control" id = "archivo" name = "archivo" accept="application/pdf, application/msword">
		</div>
		</div>
		
		<div class = "form-group">
			<div class = "botones">
			<a href = "comparte.php" class = "btn-default">Regresar</a>
			<button type = "submit" class = "btn-primary">Guardar</button>
			</div>
		
		</div>
		</form>

	</div>
	<div class= "validacion" id="fbox2">
		<h2 align = "left" class="title">Descarga datasheets</h2>
		<p>Aquí puedes descargar los datasheet que hay disponibles</p> 
		<form align = "center" class = "form-horizontal" method = "GET" action = "">
		<div class= "main-fbox2-container" >
		<table align="left" border='1' width= '30%'>
    	<thead>
    	<tr>
    		<th>ID</th>
			<th>DATASHEET_NAME</th>
    	<!--	<th>Contenido</th> -->
			<th>DESCARGA</th>
    	</tr>
    	</thead>
		<tbody>
		
		

		<?php
		/*Con este query vamos a nuestra base de datos a buscar todo lo
		que tenemos en la tabla datasheet y luego lo imprimimos como
		tabla en la pantalla, con el botón seleccionamos cual queremos consultar*/
		include 'config/conexion.php';
		$db = new conexion();
		$consulta = "SELECT * FROM datasheet ORDER BY ID ASC ";
		$res_consulta= mysqli_query($db, $consulta);
		while($rows=mysqli_fetch_array($res_consulta))
			{
    			echo "<tr>";
    			echo "<td>"; echo $rows['ID']; echo "</td>";
    			echo "<td>"; echo $rows['DATASHEET_NAME']; echo "</td>";
    			//echo "<td>"; echo $rows['Contenido']; echo "</td>";
    			echo "<td> <a href='search.php?ID=".$rows['ID']."'><button type='button' class='btn-query'>Descargar</button></a> </td>";
    			echo "</tr>"; 
			}
		?>
		</tbody>
		</table>
		</div>
		</form>
	</div>
</div>
<div id="copyright" class="container">
	<p>&copy; JOSG. All rights reserved 2019.| Las siguientes marcas tienen copyright se utilizan datasheets solo como ilustrativos de la materia |&copy;Juniper Networks| &copy;Cisco Systems| &copy;Oracle Inc  |Template Design by <a href="http://templated.co" rel="nofollow">TEMPLATED</a>.</p>
</div>
</body>
</html>

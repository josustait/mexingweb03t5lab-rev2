<html>
<body>
<?php
//Script de uploads
/*En este script manejaremos la carga de archivo hacia la base de datos*/
//obtener archivo, en este caso los archivos viajan 
//en una carpeta temporal y depsues la mandamos a nuestro server
//tmp_name es la variable que almacena el archivo temporalmente

$nombre_archivo = $_FILES['archivo'] ['name'];
$tipo_archivo = $_FILES['archivo'] ['type'];
$size_archivo = $_FILES['archivo'] ['size'];
$tmp_name = $_FILES['archivo']['tmp_name'];


if ($_FILES['archivo'] ['error']>0 )
{
	echo "inserta un archivo válido (pdf o word)";
}else{
	
	include 'config/conexion.php'; /*incluimos la conexion a la db.*/
	$db = new conexion();
	
	/*Se solicita un path que está almacenado en el archivo dir.php, el cual será concatenado
	  con la variable a_servidor que contiene grabado el directorio raiz
	*/
	require_once "dir.php";
	
	/*Se agregan timeout a la conexion y al socket, para que no se pierdan mientras
	  se cargan los arhivos. (En la base de datos se guardan como tipo BLOB binarios)
	*/	
	
	ini_set('mysqli.connect_timeout', 1200);
	ini_set('default_socket_timeout', 1200);
	
	/*Se declara el path donde se guardarian los archivos (no voy a utilizar esta variable, solo para dejar la ruta, 
	  en caso de requerir el folder a guardar, se utilizaría más delante en caso de ver que se está limitando el tamaño)
	*/
	$a_servidor = $_SERVER['DOCUMENT_ROOT'] . $dirname;
	
	/*Al archivo temporal le quitamos los slashes de C y los cambia a como los pueda interpetar php*/ 
	$archivo = addslashes (file_get_contents($tmp_name));
	
	/*Se ejecuta el query para insertar el archivo en bytes a la base de datos*/	
	$sql = "INSERT INTO datasheet (ID, DATASHEET_NAME, Contenido, LINK) VALUES ('', '$nombre_archivo', '$archivo', '$a_servidor')";
	$sql_result = mysqli_query($db,$sql) or die ("No se ha guardado el archivo valide conexion a bd");
	
	/*Validamos, si hay valor en la variable sql result, entonces manda notificación que se cargó correctamente
	Espera 2000 milisegundos (2 segundos) y redirecciona a la página, en caso de falla manda mensaje de error.*/
	
	if ($sql_result > 0)
		{
						
		    echo "Archivo almacenado correctamente  en db y pesa ($size_archivo) bytes..";
			mysqli_close($db);
			
		} else
			{
				echo "No se pudo almacenar en db, valida la conexión al servidor o revisa tu conexión de internet";
				mysqli_close($db);
			}			
}
?>
			
			<script type="text/javascript">
				setTimeout(function (){
				window.location.href='comparte.php';
				},2000);
			</script>
</body>
</html>
<?php
//Agregamos la conexión
include ('config/conexion.php');
 //confirmamos que la variable ID viene con el dato desde comparte.php boton descargar
if (isset($_GET['ID']))
    {
       //si tiene valor generamos la variable output para que contenga esa información 
        $output = $_GET['ID'];
        
      //  echo "$output";  <-Este lo agregué para validar que el ID esté presente.
      //  se abre la conexión a la bd y se ejecuta el query, buscando por la columna en donde se almacenó el archivo
      //  se guarda la consulta en la variable $res_consulta y luego se asigna a un arreglo para poder extraerlo
      //  posteriormente se crea un if para validar que no hubo error en la consulta y si no hubo error, entonces
      //  se manda llamar el archivo en este caso se deja para pdf. Una vez que se obtiene el archivo, se cierra la conexión a la db.
            $db= new conexion();
            $sql = "SELECT Contenido FROM datasheet WHERE ID = '".$output."' ";
            $res_consulta= mysqli_query($db, $sql);
            $f =mysqli_fetch_array($res_consulta);
            if(!$f)
                {
                
                    printf ("Error %s \n", mysqli_error($db));
                
                }else
                    {
                        header('Content-type: application/pdf');
                        echo $f['Contenido'];
                        mysqli_close($db);
                        
                    }    
    } else
        {
            echo "No se pudo ejecutar consulta, o Archivo no encontrado";
        }

?>